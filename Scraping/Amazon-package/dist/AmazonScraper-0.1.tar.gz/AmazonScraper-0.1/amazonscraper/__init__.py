name = 'amazonscraper'
from Scraper import Scraper 
from LinkExtractor import LinkExtractor